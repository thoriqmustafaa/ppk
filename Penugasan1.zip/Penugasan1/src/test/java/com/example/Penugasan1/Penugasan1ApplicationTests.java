package com.example.Penugasan1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Penugasan1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
