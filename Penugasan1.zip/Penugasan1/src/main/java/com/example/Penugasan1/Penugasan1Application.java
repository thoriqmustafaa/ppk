package com.example.Penugasan1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Penugasan1Application {

	public static void main(String[] args) {
		SpringApplication.run(Penugasan1Application.class, args);
	}

}
